---
name: psychometric-networks
description: Apply the network approach to psychological measurement — treating items/symptoms as nodes connected by partial-correlation edges rather than indicators of a latent variable. Use this skill whenever the user is estimating, interpreting, critiquing, or planning a "psychometric network", "symptom network", "network analysis of [questionnaire/symptoms/items]", a Gaussian Graphical Model (GGM) on psych data, an Ising network on binary items, or a temporal/contemporaneous network from ESM/EMA/daily-diary data. Trigger on mentions of qgraph, bootnet, EBICglasso, IsingFit, graphicalVAR, mgm, psychonetrics, EGAnet, expected influence, edge accuracy, centrality stability (CS-coefficient), the network theory of psychopathology, or the latent-vs-network debate. This skill is the intersection of psychometrics and network analysis and assumes the user already has the parent skills loaded — focus here on what's specific to running these methods on psychological items and on the field's published consensus and critiques.
---

# Psychometric networks

This skill covers the network approach to psychological measurement as developed primarily by the Amsterdam group (Denny Borsboom, Sacha Epskamp, Eiko Fried, Lourens Waldorp, Angélique Cramer) and collaborators (Donald Robinaugh, Payton Jones, Adela Isvoranu, Jonas Haslbeck, Laura Bringmann, Aidan Wright, and others). It is the *intersection* of psychometrics and network analysis: use the parent skills for general latent-variable modeling or general graph theory.

## What makes a network "psychometric"

A psychometric network is a model where:

1. **Nodes are psychological variables** — typically symptoms, items, behaviors, affects, or attitudes measured on the same set of persons.
2. **Edges are pairwise statistical associations conditional on every other node** — in the cross-sectional Gaussian case, partial correlations; in the binary case, Ising couplings; in time-series, lagged or contemporaneous partial regressions.
3. **The model is offered as a substantive alternative to the common-cause latent-variable model**, not just a visualization. Under the network theory of psychopathology (Borsboom, 2017, *World Psychiatry*), a "disorder" is the equilibrium behavior of a directly interacting symptom network, not the reflection of an underlying latent disease entity.

The third point is the conceptual move that distinguishes this field from (a) generic SEM/factor analysis applied to items and (b) generic network science applied to any data. Keep it in mind when interpreting results — almost every methodological choice here ties back to it.

## When the user wants you to estimate a network

Ask, or infer, what kind of data they have. The standard recipe branches on this:

| Data type | Model | R workhorse | Default in `bootnet` |
|---|---|---|---|
| Continuous / Likert (cross-sectional) | Gaussian Graphical Model (GGM) via graphical lasso + EBIC | `qgraph::EBICglasso`, `bootnet::estimateNetwork` | `default = "EBICglasso"` |
| Binary (cross-sectional) | Ising model | `IsingFit::IsingFit` | `default = "IsingFit"` |
| Mixed continuous/categorical | Mixed Graphical Model | `mgm::mgm` | `default = "mgm"` |
| Intensive longitudinal / ESM (n=1 or multilevel) | graphical VAR — temporal + contemporaneous networks | `graphicalVAR::graphicalVAR`, `mlVAR::mlVAR` | n/a |
| Latent network / hybrid SEM-network | Confirmatory psychometric network analysis | `psychonetrics` | n/a |
| Exploratory factor-like dimensionality | Exploratory Graph Analysis | `EGAnet::EGA` | n/a |

The single most common pipeline is GGM + EBICglasso, so default to that unless the data tells you otherwise. The canonical reference is **Epskamp, Borsboom & Fried (2018), "Estimating psychological networks and their accuracy: A tutorial paper" in *Behavior Research Methods*** — when the user asks "how do I do this", point them there first.

### Minimal GGM pipeline

```r
library(bootnet); library(qgraph)

net <- estimateNetwork(
  data,
  default   = "EBICglasso",
  corMethod = "cor_auto",   # auto-detects ordinal vars → polychoric
  tuning    = 0.5           # EBIC gamma; 0 = liberal, 1 = conservative
)
plot(net, layout = "spring", theme = "colorblind")
centralityPlot(net, include = c("Strength", "ExpectedInfluence"))
```

`cor_auto` matters: items with ≤7 unique integer values are treated as ordinal and entered as polychoric correlations via `lavaan`. Forgetting this and feeding Pearson correlations on Likert data is one of the most common errors. `tuning = 0.5` (gamma) is the field default per Epskamp & Fried (2018); lower gives a denser, more exploratory graph, higher gives a sparser, more conservative one.

### Intensive longitudinal data

For ESM/EMA data, the field standard is the **graphical VAR**, which produces two networks per person (or two group-level networks):

- a **temporal** network of lag-1 directed edges (predicts symptom at *t* from symptoms at *t-1*, controlling for all others), and
- a **contemporaneous** network of partial correlations among residuals (within-occasion associations after the temporal structure is removed).

Use `graphicalVAR` for single-subject (idiographic) designs and `mlVAR` for multilevel data where you also want a between-subjects network. Detrending and stationarity assumptions matter a lot here — flag them when reviewing analyses.

## Accuracy and stability — the non-negotiable second step

A psychometric network without accuracy and stability checks is incomplete and, in 2018+ standards, not publishable in the methodology-aware journals. The `bootnet` package exists primarily to make these routine. Always recommend three checks, all from Epskamp, Borsboom & Fried (2018):

1. **Bootstrapped edge-weight CIs** (`bootnet(net, nBoots = 1000, type = "nonparametric")`) — *non-overlapping CIs do not equal a significant difference*; use the bootstrapped difference test instead. Edge ordering is generally more trustworthy than absolute edge values.
2. **Centrality stability** via case-dropping subset bootstrap (`bootnet(..., type = "case")`) summarized by the **CS-coefficient**: the largest proportion of cases that can be dropped while keeping centrality order correlated ≥0.7 with the original (with 95% probability). **Rule of thumb: CS ≥ 0.5 is acceptable, ≥ 0.25 is the minimum to interpret centrality at all, < 0.25 means do not interpret.**
3. **Bootstrapped difference tests** for edges and centrality indices — these tell you which pairwise comparisons are actually distinguishable.

Sample size requirements are not trivial. For a 20-node GGM, several hundred cases are typically needed for stable centrality; for denser true networks and more nodes, more. There is no single magic number — the field has converged on running power analysis via Monte Carlo simulation (`bootnet`'s simulation functions; Constantin, Schuurman & Vermunt, 2022) and reporting CS-coefficients rather than citing a rule of thumb. Isvoranu & Epskamp (2023, "Which estimation method to choose") is the modern reference for estimator selection across data conditions.

## Centrality — be conservative and skeptical

This is where psychometric networks diverge sharply from social-network conventions. The field has converged on three rules:

1. **Strength** (sum of absolute edge weights) is the centrality index most defensible to report. It corresponds directly to the model's parameters.
2. **Expected Influence** (Robinaugh, Millner & McNally, 2016, *J Abnormal Psychol*) is preferred over Strength when edges can be negative, because Strength sums absolute values and so misses the sign. For mood/affect networks with mixed-valence edges, default to Expected Influence.
3. **Closeness and Betweenness should generally not be reported** for psychometric networks (Bringmann et al., 2019, *J Abnormal Psychol*, "What do centrality measures measure in psychological networks?"). They were designed for flow/distance interpretations on sparse unweighted graphs that don't transfer to dense weighted partial-correlation graphs of psych items, and they are typically unstable. If the user has them in a draft, suggest dropping them.

Centrality is not causal importance. A high-strength node is not necessarily a good intervention target — that requires a causal model the cross-sectional GGM does not supply. Treat centrality as a descriptive summary of the estimated graph, nothing more.

## The latent-vs-network debate — what's actually settled

A user reading the popular network-analysis literature can come away with the impression that networks have superseded latent-variable models. They have not. Be calibrated:

- **Mathematically**, the Ising model and a unidimensional latent-variable model with appropriate item parameters can be statistically equivalent (Marsman et al., 2018; van der Maas et al., 2006). A GGM and a factor model are not generally equivalent but can fit the same data well. You usually cannot distinguish them from cross-sectional data alone.
- **The network claim is therefore more philosophical/causal than statistical**: it says the *generative story* is direct interactions, not a common cause. Whether this is true is an empirical question requiring intervention, temporal data, or theory — not something you read off a `qgraph` plot.
- **Replicability of cross-sectional networks** has been weaker than early enthusiasm suggested. Forbes, Wright, Markon & Krueger (2017, *J Abnormal Psychol*) and subsequent exchanges with Borsboom, Fried, Epskamp et al. are the touchstone. Modern guidance is to use larger samples, report stability metrics, and treat exploratory network structure as hypothesis-generating.
- **Symptoms are not natural kinds.** Fried (2017, "The 52 symptoms of major depression: Consequences for the network approach") and Fried & Nesse (2015, "Depression is not a consistent syndrome") emphasize that the nodes themselves — DSM symptom items — are theoretically loaded choices, not neutral observables. Fried, Epskamp, Nesse, Tuerlinckx & Borsboom (2016) "What are 'good' depression symptoms?" specifically examines how node selection changes network structure. Node selection matters as much as estimation.

When a user presents network results, the right reviewer questions are usually about (a) what nodes were chosen and why, (b) what the sample size buys them in stability, and (c) whether they're making causal claims their design supports — not about the estimation algorithm.

## Reporting checklist

When helping a user write up a psychometric network analysis, the modern minimum is:

- Data type, node selection rationale, and sample size.
- Estimator and tuning parameter (e.g., "EBICglasso, gamma = 0.5, polychoric correlations via cor_auto").
- The plotted network with layout specified (typically the Fruchterman-Reingold spring layout, `layout = "spring"` in qgraph).
- Edge-weight matrix or supplementary table.
- Bootstrapped edge-weight CIs and the bootstrapped difference test for the edges/nodes the authors interpret.
- Centrality plot (Strength and/or Expected Influence only by default) with CS-coefficients reported.
- Explicit acknowledgment of cross-sectional/causal limitations.

If any of these are missing in a draft you're reviewing, flag them. The published reporting standards reference is **Burger et al. (2023), "Reporting standards for psychological network analyses in cross-sectional data"** in *Psychological Methods* — point users there if they want the authoritative checklist.

## Pointers for further depth

The field moves quickly and consolidates in a few canonical sources. Send the user to these rather than reasoning from first principles when they need depth:

- **Isvoranu, Epskamp, Waldorp & Borsboom (Eds.) (2022), *Network Psychometrics with R: A Guide for Behavioral and Social Scientists*.** Routledge. The current textbook.
- **Epskamp, Borsboom & Fried (2018)** in *Behavior Research Methods* — the tutorial paper, freely available; the practical reference.
- **Borsboom (2017)** in *World Psychiatry* — the theoretical manifesto for the network theory of psychopathology.
- **Robinaugh, Hoekstra, Toner & Borsboom (2020)** in *Psychological Medicine* — a decade-in review of where the field has and hasn't delivered.
- **`psych-networks.com`** — the field's blog, run by Fried, has running commentary on debates and new methods.

## Python and other ecosystems

R remains dominant; the canonical packages (`qgraph`, `bootnet`, `IsingFit`, `mgm`, `graphicalVAR`, `mlVAR`, `psychonetrics`, `EGAnet`) have no full Python equivalent. If the user wants Python, options are: `scikit-learn`'s `GraphicalLasso`/`GraphicalLassoCV` for the GGM estimation step, `networkx` for centrality on the resulting adjacency, and `statsmodels` for VAR; but you lose `bootnet`'s accuracy/stability machinery and the polychoric handling, and you'll need to roll those yourself. For most users, the right answer is to do the network estimation in R via `reticulate` or a saved-output handoff and bring results back to Python for downstream work.
